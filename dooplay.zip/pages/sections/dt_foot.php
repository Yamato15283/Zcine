	<div class="text_ft"><?php bloginfo('name'); ?> &copy; <?php echo date('Y'); ?></div>
	</div>
</div>
</body>
</html>