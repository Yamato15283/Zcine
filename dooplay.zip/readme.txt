== DooPlay 2.1.3.96 ==
Contributors: Doothemes team
Requires at least: WordPress 4.3
Tested up to: WordPress 4.8.3
Version: 2.1.3.96
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Copyright ==

DooPlay WordPress Theme, Copyright 2017-2018 doothemes.com & themes.pe

== Change Log ==


= 2.1.3.96 =
* Released: January 29, 2018

https://doothemes.com/items/dooplay/?view=changelog#version_2.1.3.96

= 2.1.3.9 =
* Released: October 22, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.1.3.9

= 2.1.3.8 =
* Released: October 01, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.1.3.8

= 2.1.3.5 =
* Released: October 23, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.1.3.5

= 2.1.3 =
* Released: October 20, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.1.3

= 2.1 =
* Released: July 11, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.1

= 2.0.7 =
* Released: June 14, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.7

= 2.0.6 =
* Released: June 10, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.6

= 2.0.5 =
* Released: June 8, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.5

= 2.0.4 =
* Released: May 28, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.4

= 2.0.3 =
* Released: May 20, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.3

= 2.0.2 =
* Released: April 15, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.2

= 2.0.1 =
* Released: April 14, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.1

= 2.0 =
* Released: April 7, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.0
